<?php
include 'cabecalho.php';
?>
<div>
	<div class="superior">
		<center><h1>Pagina Usuario</h1></center>

	</div>
	<div class="menu_usuario">
		<img class="img_usuario" src="img/usuario.png">
		<hr style="height:2px; border:none; color:#000; background-color:#000; margin-top: 5%; margin-bottom: 0px;"/>

		<center><p class="dados_institucionais">Dados Institucionais:</p> </center>
		<p class="dados_insti_subtitulo">Matricula:</p> 
		<p class="dados_insti_subtitulo">Turma:</p> 
		<p class="dados_insti_subtitulo">Curso:</p> 
		<p class="dados_insti_subtitulo">Email:</p> 

		<hr style="height:2px; border:none; color:#000; background-color:#000; margin-top: 5%; margin-bottom: 0px;"/>

		<button type="button" class="btn btn-outline-dark botao_usuario">Realizar Ocorrência</button>
		<button type="button" class="btn btn-outline-dark botao_usuario">exemplo</button>



	</div>
	<div class="lateral_superior">

		<div class="historico">

			<table class="demo">

				<thead>
					<tr>
						<th>Codigo</th>
						<th>Data Ocorrência</th>
						<th>Tipo Ocorrêcia </th>
						<th>Motivo</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>
		</div>



	</div>






</div>